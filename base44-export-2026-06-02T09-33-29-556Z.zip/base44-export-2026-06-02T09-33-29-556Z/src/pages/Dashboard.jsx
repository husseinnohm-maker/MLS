const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";

import { useAuth } from "@/lib/AuthContext";
import { Navigate } from "react-router-dom";
import DashboardFilters from "../components/DashboardFilters";
import DashboardStats from "../components/DashboardStats";
import DashboardTable from "../components/DashboardTable";
import DashboardCharts from "../components/DashboardCharts";
import ExportButton from "../components/ExportButton";

export default function Dashboard() {
  const { user } = useAuth();
  const [filters, setFilters] = useState({
    region: "",
    division: "",
    temp_zone: "",
    date_from: "",
    date_to: "",
  });

  const { data: allEntries = [], isLoading } = useQuery({
    queryKey: ["pallet-entries", "all"],
    queryFn: () => db.entities.PalletEntry.list("-entry_date", 500),
  });

  const filtered = useMemo(() => {
    return allEntries.filter((e) => {
      if (filters.region && e.region !== filters.region) return false;
      if (filters.division && e.division !== filters.division) return false;
      if (filters.temp_zone && e.temp_zone !== filters.temp_zone) return false;
      if (filters.date_from && e.entry_date < filters.date_from) return false;
      if (filters.date_to && e.entry_date > filters.date_to) return false;
      return true;
    });
  }, [allEntries, filters]);

  if (user?.role !== "admin") {
    return <Navigate to="/" replace />;
  }

  if (isLoading) {
    return (
      <div className="flex justify-center py-20">
        <div className="w-8 h-8 border-3 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-heading text-2xl font-bold">Admin Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Consolidated view across all warehouses, regions, and divisions.
          </p>
        </div>
        <ExportButton entries={filtered} />
      </div>

      <DashboardFilters filters={filters} setFilters={setFilters} />
      <DashboardStats entries={filtered} />
      <DashboardCharts entries={filtered} />
      <DashboardTable entries={filtered} isAdmin={true} />
    </div>
  );
}