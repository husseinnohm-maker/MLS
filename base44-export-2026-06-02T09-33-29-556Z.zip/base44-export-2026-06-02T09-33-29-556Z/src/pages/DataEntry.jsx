const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useAuth } from "@/lib/AuthContext";
import { useQuery } from "@tanstack/react-query";

import DataEntryForm from "../components/DataEntryForm";
import DashboardTable from "../components/DashboardTable";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import moment from "moment";

export default function DataEntry() {
  const { user } = useAuth();
  const today = new Date().toISOString().split("T")[0];

  const { data: todayEntries = [], isLoading } = useQuery({
    queryKey: ["pallet-entries", "today", user?.id],
    queryFn: async () => {
      const filter = { entry_date: today };
      if (user?.role === "warehouse_user" && user?.assigned_warehouse) {
        filter.warehouse = user.assigned_warehouse;
      }
      return db.entities.PalletEntry.filter(filter, "-created_date", 100);
    },
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-heading text-2xl font-bold">Daily Staging Entry</h1>
        <p className="text-sm text-muted-foreground mt-1">
          {moment().format("dddd, D MMMM YYYY")} — Record pallet counts for your warehouse.
        </p>
      </div>

      <Tabs defaultValue="new" className="space-y-4">
        <TabsList>
          <TabsTrigger value="new">New Entry</TabsTrigger>
          <TabsTrigger value="today">Today's Entries ({todayEntries.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="new">
          <div className="max-w-2xl">
            <div className="bg-card border rounded-xl p-6">
              <DataEntryForm user={user} />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="today">
          {isLoading ? (
            <div className="flex justify-center py-12">
              <div className="w-6 h-6 border-2 border-muted border-t-primary rounded-full animate-spin" />
            </div>
          ) : (
            <DashboardTable entries={todayEntries} isAdmin={false} />
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}